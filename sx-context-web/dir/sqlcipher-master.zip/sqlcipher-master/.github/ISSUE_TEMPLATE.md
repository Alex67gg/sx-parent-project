### Expected Behavior

### Actual Behavior

### Steps to Reproduce

SQLCipher version:

*Note:* If you are not posting a specific issue for the SQLCipher library, please consider posting your question to the SQLCipher [discuss site](https://discuss.zetetic.net/c/sqlcipher).  Thanks!
